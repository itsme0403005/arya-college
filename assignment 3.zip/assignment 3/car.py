class Vehicle:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year
class Car(Vehicle):
    def __init__(self, make, model, year, doors):
        super().__init__(make, model, year)
        self.doors = doors
class Bike(Vehicle):
    def __init__(self, make, model, year, engine_cc):
        super().__init__(make, model, year)
        self.engine_cc = engine_cc

car = Car('Toyota', 'S1', 2011, 4)
bike = Bike('Wego', 'S1', 2012, 321)
print(f'Car: {car.make} {car.model} {car.year} {car.doors}-door')
print(f'Bike: {bike.make} {bike.model} {bike.year} {bike.engine_cc}cc')
