keys = ['a', 'b', 'c']
values = [1, 2, 3]
dictionary = dict(map(lambda k, v: (k, v), keys, values))
print(dictionary)
