#single,multiple,multilvl,hybrid,hierirchical
#single level
class a:
    name="m hu giyan"
class b(a):
    print("acha ji")
b1=a()
print(b1.name)
#multilvl
class aa:
    name="i"
class bb(aa):
    name2="am"
class cc(bb):
    print("mussu")
c3=cc()
c3.name
print(cc.name)
c3.name2
print(cc.name2)

#multiple
class a:
    name="me"
class b():
    name2="mine"
class c(b,a):
    print("mera")
c1=c()
c1.name
print(c.name)
c1.name2
print(c.name2)

#hybrid
class a:
    name="hn"
class b:
    name2="hmm"
class c(b,a):
    name3="hurrah"
class d(c):
    print("hnji")
d1=d()
d1.name
print(d.name)
d1.name2
print(d.name2)
d1.name3
print(d.name3)

#hierichical


